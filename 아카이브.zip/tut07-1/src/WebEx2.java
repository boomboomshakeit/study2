
class Hello2 {

	public void welcom() {
		System.out.println("코리아아이티 아카데미");
	}
}

public class WebEx2 {

	public static void main(String[] args) {
		Hello2 h = new Hello2();
		h.welcom();
		h.welcom();
	}

}
