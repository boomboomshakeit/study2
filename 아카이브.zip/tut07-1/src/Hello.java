
public class Hello {

	public void welcom() {
		System.out.println("코리아아이티 아카데미");
	}
}
