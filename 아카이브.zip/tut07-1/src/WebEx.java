//
////class Hello {
////	//Welcojme, void(sysout)
////		//접근제한자 리턴타입 메소드명(){}
////		public void welcom() {
////			System.out.println("코리아아이티 아카데미 웹 사이트에 오신 것을 환영합니다.");
////		}
////}
//
//public class WebEx {
//
//	
//	
//	public static void main(String[] args) {
//		
//		//코리아아이티 아카데미 웹 사이트에 오신 것을 환영합니다.
//		//코리아아이티 아카데미 웹 사이트에 오신 것을 환영합니다.
//
//		Hello h = new Hello();
//		h.welcom();
//		h.welcom();
//		
//		
//		
//		
//		
//		
//		
//	}
//
//}
