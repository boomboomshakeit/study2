package tut07;

public class IFEx {

	public static void main(String[] args) {
		
		//임의의 점수(정수) 생성 :0 ~ 100
		//점수가 90보다 크고 100점보다는 적으 A학점
		//80보다 크면 B 학점
		
		int num = 91;	//변수를 선언 -> 메모리 생성 -> 값X ->	 초기화작업
		
		int[] num2;	//변수를 선언 -> 메모리 생성 -> 값X
		
		if(num >= 90) {
			System.out.println("100점보다는 적습니다.");
			System.out.println("A학점 입니다.");
		} else {
			System.out.println("100점보는 적습니다.");
			System.out.println("학점은 B학점입니다.");
		}
		
		
		
		
		
		
		
		
		
	}

}
